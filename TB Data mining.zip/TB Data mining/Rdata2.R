#lokasi kerja
setwd("c:/TB Data mining")
getwd()
install.packages('C50', dependencies = T)
install.packages("printr")
library(C50)
library(printr)
#import dataset
dataset <- read.csv("dataR2.csv", sep = ",")
dataset$Classification<-as.factor(dataset$Classification)
class(dataset$Classification)
#membuat model 
model <- C5.0(Classification~., data = dataset)
summary(model)
plot(model)
datatesting <- dataset[,1:9]
predictions <- predict(model, dataset)
table(predictions, dataset$Classification)
